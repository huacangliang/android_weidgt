package com.lazymc.test;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.ks.controller.UserController;
import com.ks.pojo.LoginInfo;
import com.ks.pojo.User;
import com.ks.service.IUserService;
import com.ks.utils.ResponseMsg;

@RunWith(SpringJUnit4ClassRunner.class)
// 表示继承了SpringJUnit4ClassRunner类
@ContextConfiguration(locations = { "classpath:spring-mybatis.xml" })
public class TestMyBatis {
	private static Logger logger = Logger.getLogger(TestMyBatis.class);

	@Resource
	private IUserService userService = null;

	// @Test
	// public void testTransaction() {
	// List<User> users = new ArrayList<User>();
	// for (int i = 1; i < 5; i++) {
	// User user = new User();
	// user.setKsName("name_" + i);
	// user.setKsName("nickname_" + i);
	// user.setKsPhone("1234567890" + i);
	// users.add(user);
	// }
	// boolean re = this.userService.insertUser(users);
	// if (re)
	// System.out.println("插入成功");
	// else
	// System.out.println("插入失败");
	// }

	@Test
	public void test1() {
	
	}
}
