package com.ks.service;

import java.util.List;

import com.ks.pojo.News;

public interface INewsService {
	boolean addNews(News news);
	boolean updateNews(News news);
	boolean delNews(int id);
	List<News> getNewsByPage(String title,int pageNum,int size);
}
