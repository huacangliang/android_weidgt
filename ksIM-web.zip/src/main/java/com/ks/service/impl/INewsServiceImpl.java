package com.ks.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ks.mapping.NewsMapper;
import com.ks.pojo.News;
import com.ks.service.INewsService;

@Service("newsService")
public class INewsServiceImpl implements INewsService {
	
	@Resource
	private NewsMapper newsMapper;

	@Override
	@Transactional
	public boolean addNews(News news) {
		// TODO Auto-generated method stub
		return newsMapper.insertSelective(news)>0?true:false;
	}

	@Override
	@Transactional
	public boolean updateNews(News news) {
		// TODO Auto-generated method stub
		return newsMapper.updateByPrimaryKeySelective(news)>0?true:false;
	}

	@Override
	@Transactional
	public boolean delNews(int id) {
		// TODO Auto-generated method stub
		return newsMapper.deleteByPrimaryKey(id)>0?true:false;
	}

	@Override
	public List<News> getNewsByPage(String title,int pageNum,int size) {
		// TODO Auto-generated method stub
		com.github.pagehelper.PageHelper.offsetPage(pageNum * size, size
				* (pageNum + 1));
		return newsMapper.selectByParam(title);
	}

}
