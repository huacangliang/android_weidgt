package com.ks.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ks.mapping.LoginInfoMapper;
import com.ks.pojo.LoginInfo;
import com.ks.service.ILoginInfoService;

@Service("loginInfoService")
public class ILoginInfoServiceImpl implements ILoginInfoService{
	
	@Resource
	private LoginInfoMapper loginInfoMapper;

	@Override
	public boolean add(LoginInfo loginInfo) {
		// TODO Auto-generated method stub
		return loginInfoMapper.insert(loginInfo)>0?true:false;
	}

	@Override
	public boolean delById(String phone) {
		// TODO Auto-generated method stub
		return loginInfoMapper.deleteByPhoneNum(phone)>0?true:false;
	}

	@Override
	public boolean update(LoginInfo lonInfo) {
		// TODO Auto-generated method stub
		return loginInfoMapper.updateByPrimaryKeySelective(lonInfo)>0?true:false;
	}

	@Override
	public LoginInfo findByPhoneNum(String phone) {
		// TODO Auto-generated method stub
		return loginInfoMapper.selectByPhoneNum(phone);
	}

	@Override
	public List<LoginInfo> findByPage(int pageNum, int PageSize) {
		// TODO Auto-generated method stub
		com.github.pagehelper.PageHelper.offsetPage(pageNum * PageSize, PageSize
				* (pageNum + 1));
		return loginInfoMapper.selectByPage();
	}

}
