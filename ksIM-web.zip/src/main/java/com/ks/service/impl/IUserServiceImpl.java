package com.ks.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ks.mapping.UserMapper;
import com.ks.pojo.User;
import com.ks.service.IUserService;

@Service("userService")
public class IUserServiceImpl implements IUserService {

	@Resource
	private UserMapper userMapper;

	@Override
	@Transactional
	public boolean insertUser(List<User> users) {
		// TODO Auto-generated method stub
		try {
			for (int i = 0; i < users.size(); i++) {
				int ex = userMapper.insert(users.get(i));
				if (ex <= 0) {
					throw new Exception("insert user error");
				}
			}
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<User> getByPage(int pageNum, int size) {
		// TODO Auto-generated method stub
		// mysql只能使用该方式分页
		com.github.pagehelper.PageHelper.offsetPage(pageNum * size, size
				* (pageNum + 1));
		List<User> obj = userMapper.selectByParam(null);
		return obj;
	}

	@Override
	public User getById(int id) {
		// TODO Auto-generated method stub
		return userMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<User> getByQuery(User user) {
		// TODO Auto-generated method stub
		return userMapper.selectByParam(user);
	}

	@Override
	@Transactional
	public boolean update(User user) {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKeySelective(user)>0?true:false;
	}

	@Override
	@Transactional
	public boolean delete(User user) {
		// TODO Auto-generated method stub
		return userMapper.deleteByPrimaryKey(user.getKsUid())>0?true:false;
	}

}
