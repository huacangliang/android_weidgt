package com.ks.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ks.mapping.LoginInfoMapper;
import com.ks.mapping.MessageMapper;
import com.ks.pojo.LoginInfo;
import com.ks.pojo.Message;
import com.ks.service.IMessageService;

@Service("messageService")
public class IMessageServiceImpl implements IMessageService {

	@Resource
	private MessageMapper messageMapper;
	
	@Resource
	private LoginInfoMapper loginInfoMapper;
	
	@Override
	public boolean addMsg(Message msg) {
		// TODO Auto-generated method stub
		return messageMapper.insert(msg)>0?true:false;
	}

	@Override
	public boolean updateMsg(Message msg) {
		// TODO Auto-generated method stub
		return messageMapper.updateByPrimaryKeySelective(msg)>0?true:false;
	}

	@Override
	public boolean delMsg(Integer id) {
		// TODO Auto-generated method stub
		return messageMapper.deleteByPrimaryKey(id)>0?true:false;
	}

	@Override
	public Message findById(Integer id) {
		// TODO Auto-generated method stub
		return messageMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Message> findByPage(Message msg, int pageNum, int pageSize) {
		// TODO Auto-generated method stub
		com.github.pagehelper.PageHelper.offsetPage(pageNum * pageSize, pageSize
				* (pageNum + 1));
		
		return messageMapper.selectByParam(msg);
	}

	@Override
	public boolean loginIM(LoginInfo li) {
		// TODO Auto-generated method stub
		return loginInfoMapper.insert(li)>0?true:false;
	}

	@Override
	public boolean logout(String phone) {
		// TODO Auto-generated method stub
		return loginInfoMapper.deleteByPhoneNum(phone)>0?true:false;
	}

}
