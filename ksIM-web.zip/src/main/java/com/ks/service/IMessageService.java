package com.ks.service;

import java.util.List;

import com.ks.pojo.LoginInfo;
import com.ks.pojo.Message;

public interface IMessageService {
	public boolean addMsg(Message msg);
	
	public boolean updateMsg(Message msg);
	
	public boolean delMsg(Integer id);
	
	public Message findById(Integer id);
	
	public List<Message> findByPage(Message msg,int pageNum,int pageSize);
	
	boolean loginIM(LoginInfo li);
	
	boolean logout(String phone);
}
