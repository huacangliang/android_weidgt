package com.ks.service;

import java.util.List;

import com.ks.pojo.LoginInfo;

public interface ILoginInfoService {
	boolean add(LoginInfo loginInfo);
	boolean delById(String phone);
	boolean update(LoginInfo lonInfo);
	LoginInfo findByPhoneNum(String phone);
	List<LoginInfo> findByPage(int pageNum,int PageSize);
}
