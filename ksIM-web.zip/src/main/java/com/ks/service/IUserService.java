package com.ks.service;

import java.util.List;

import com.ks.pojo.User;

public interface IUserService {
	
	boolean insertUser(List<User> users);
	
	List<User> getByPage(int pageNum,int size);
	
	User getById(int id);
	
	List<User> getByQuery(User user);
	
	boolean update(User user);
	
	boolean delete(User user);
}
