package com.ks.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ks.commo.Constants;
import com.ks.pojo.News;
import com.ks.service.INewsService;
import com.ks.utils.ResponseMsg;
import com.ks.utils.UserUtils;

@Controller("newsController")
@RequestMapping("/news")
public class NewsController extends BaseController {
	
	@Resource
	private INewsService newsService;
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value="/add",method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> addNews(HttpServletRequest request,News news){
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.ADDNEWS_ERRORCDE);
			return responseMsg;
		}
		if (newsService.addNews(news)) {
			responseMsg=new ResponseMsg();
		}else{
			responseMsg=new ResponseMsg(false,"添加资讯失败",Constants.ADDNEWS_ERRORCDE);
		}
		return responseMsg;
	}
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value="/update",method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> updateNews(HttpServletRequest request,News news){
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.ADDNEWS_ERRORCDE);
			return responseMsg;
		}
		if (newsService.updateNews(news)) {
			responseMsg=new ResponseMsg();
		}else{
			responseMsg=new ResponseMsg(false,"更新资讯失败",Constants.ADDNEWS_ERRORCDE);
		}
		return responseMsg;
	}
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value="/del",method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> delNews(HttpServletRequest request,Integer id){
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.ADDNEWS_ERRORCDE);
			return responseMsg;
		}
		if (newsService.delNews(id)) {
			responseMsg=new ResponseMsg();
		}else{
			responseMsg=new ResponseMsg(false,"删除资讯失败",Constants.ADDNEWS_ERRORCDE);
		}
		return responseMsg;
	}
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value="/selectByPage",method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> selectNews(HttpServletRequest request,String title,int pageNum,int pageSize){
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.ADDNEWS_ERRORCDE);
			return responseMsg;
		}
		
		List<News> data = newsService.getNewsByPage(title, pageNum, pageSize);
		responseMsg=new ResponseMsg<List<News>>(data);
		return responseMsg;
	}
}
