package com.ks.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ks.commo.Constants;
import com.ks.commo.IMService;
import com.ks.pojo.User;
import com.ks.service.IMessageService;
import com.ks.service.IUserService;
import com.ks.utils.ResponseMsg;
import com.ks.utils.UserUtils;

@Controller("userController")
@RequestMapping("/user")
public class UserController extends BaseController {
	
	private static Logger logger = Logger.getLogger(UserController.class);
	
	@Resource
	private IUserService userService;
	
	@Resource
	private IMessageService messageService;
	
	IMService imService=new IMService();

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg register(HttpServletRequest request, User user) {
		List<User> users = new ArrayList<User>();
		users.add(user);
		User lg = new User();
		lg.setKsPhone(user.getKsPhone());
		List lr = userService.getByQuery(lg);
		if (lr != null && lr.size() > 0) {
			responseMsg = new ResponseMsg(false, "该手机号已注册",
					Constants.REGISTER_ERRORCODE);
			logger.error(responseMsg.toString());
			return responseMsg;
		}
		boolean result = userService.insertUser(users);
		if (result) {
			responseMsg = new ResponseMsg(result);
			lr = userService.getByQuery(lg);
			request.getSession().setAttribute(Constants.SESSION_USER_NAME,
					lr.get(0));
			imService.login(messageService, user.getKsPhone());
		} else {
			responseMsg = new ResponseMsg(result, "注册失败，未知错误",
					Constants.REGISTER_ERRORCODE);
			logger.error(responseMsg.toString());
		}
		return responseMsg;
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> login(HttpServletRequest request, String ks_phone) {
		User user = new User();
		user.setKsPhone(ks_phone);
		List<User> lg = userService.getByQuery(user);
		if (lg != null && lg.size() > 0) {
			request.getSession().setAttribute(Constants.SESSION_USER_NAME,
					lg.get(0));
			responseMsg = new ResponseMsg<User>(lg.get(0));
			imService.login(messageService, ks_phone);
		} else {
			responseMsg = new ResponseMsg(false, "登陆失败，不存在该手机号",
					Constants.LOGIN_ERRORCODE);
			logger.error(responseMsg.toString());
		}
		return responseMsg;

	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/logOut", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> logOut(HttpServletRequest request, String ks_phone) {
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.LOGOUT_ERRORCODE);
			return  responseMsg;
		}
		request.getSession().setAttribute(Constants.SESSION_USER_NAME, null);
		responseMsg=new ResponseMsg();
		imService.logOut(messageService, ks_phone);
		return responseMsg;
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="findUser", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	public ResponseMsg<?> findUser(HttpServletRequest request,User user){
		if(!UserUtils.isLogin(request)){
			responseMsg=new ResponseMsg(false,"请先登录",Constants.FINDUSER_ERRORCODE);
			return  responseMsg;
		}
		List<User> users = userService.getByQuery(user);
		responseMsg=new ResponseMsg<List<User>>(users);
		return responseMsg;
		
	}
}
