package com.ks.controller;

import com.ks.utils.ResponseMsg;

public class BaseController {
	protected ResponseMsg<?> responseMsg;
}
