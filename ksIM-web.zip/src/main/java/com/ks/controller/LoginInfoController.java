package com.ks.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ks.pojo.LoginInfo;
import com.ks.service.ILoginInfoService;
import com.ks.utils.ResponseMsg;

@Controller("loginInfoController")
@RequestMapping("/loginInfo")
public class LoginInfoController extends BaseController{
	
	@Resource
	private ILoginInfoService loginInfoService;
	
	public ResponseMsg<?> add(LoginInfo loginInfo){
		loginInfoService.add(loginInfo);
		return responseMsg;
		
	}
}
