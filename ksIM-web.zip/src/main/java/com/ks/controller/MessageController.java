package com.ks.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ks.commo.Constants;
import com.ks.pojo.Message;
import com.ks.pojo.News;
import com.ks.service.IMessageService;
import com.ks.service.INewsService;
import com.ks.utils.ResponseMsg;
import com.ks.utils.UserUtils;

@Controller("messageController")
@RequestMapping("/msg")
public class MessageController extends BaseController {
	@Resource
	private IMessageService messageService;

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> addMsg(HttpServletRequest request, Message msg) {
		if (!UserUtils.isLogin(request)) {
			responseMsg = new ResponseMsg(false, "请先登录",
					Constants.ADDMSG_ERRORCODE);
			return responseMsg;
		}
		if (messageService.addMsg(msg)) {
			responseMsg = new ResponseMsg();
		} else {
			responseMsg = new ResponseMsg(false, "添加消息失败",
					Constants.ADDMSG_ERRORCODE);
		}
		return responseMsg;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/del", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> delMsg(HttpServletRequest request, Integer id) {
		if (!UserUtils.isLogin(request)) {
			responseMsg = new ResponseMsg(false, "请先登录",
					Constants.DELMSG_ERRORCODE);
			return responseMsg;
		}
		if (messageService.delMsg(id)) {
			responseMsg = new ResponseMsg();
		} else {
			responseMsg = new ResponseMsg(false, "删除消息失败",
					Constants.DELMSG_ERRORCODE);
		}
		return responseMsg;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> updateMsg(HttpServletRequest request, Message msg) {
		if (!UserUtils.isLogin(request)) {
			responseMsg = new ResponseMsg(false, "请先登录",
					Constants.DELMSG_ERRORCODE);
			return responseMsg;
		}
		if (messageService.updateMsg(msg)) {
			responseMsg = new ResponseMsg();
		} else {
			responseMsg = new ResponseMsg(false, "更新消息失败",
					Constants.DELMSG_ERRORCODE);
		}
		return responseMsg;
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/findById", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> findMsg(HttpServletRequest request, Integer id) {
		if (!UserUtils.isLogin(request)) {
			responseMsg = new ResponseMsg(false, "请先登录",
					Constants.DELMSG_ERRORCODE);
			return responseMsg;
		}
		Message msg = messageService.findById(id);
		responseMsg = new ResponseMsg<Message>(msg);
		return responseMsg;
	}
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = "/findByPage", method = RequestMethod.POST, produces = { Constants.JSONMIMETYPE })
	@ResponseBody
	public ResponseMsg<?> findMsgByPage(HttpServletRequest request, Message msg,int pageNum,int pageSize) {
		if (!UserUtils.isLogin(request)) {
			responseMsg = new ResponseMsg(false, "请先登录",
					Constants.DELMSG_ERRORCODE);
			return responseMsg;
		}
		List<Message> msgs = messageService.findByPage(msg, pageNum, pageSize);
		responseMsg = new ResponseMsg<List<Message>>(msgs);
		return responseMsg;
	}
}
