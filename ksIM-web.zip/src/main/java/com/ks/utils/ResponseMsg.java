package com.ks.utils;

import com.alibaba.fastjson.JSON;

public class ResponseMsg<T> {
	private boolean success = true;
	private String msg;
	private int code = 0;
	private T data;

	public ResponseMsg() {
		super();
	}

	public ResponseMsg(T data) {
		super();
		this.data = data;
	}

	public ResponseMsg(boolean success, String msg, int code) {
		super();
		this.success = success;
		this.msg = msg;
		this.code = code;
	}
	
	@Override
	public String toString(){
		return JSON.toJSONString(this);
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}
