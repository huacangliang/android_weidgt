package com.ks.utils;

import javax.servlet.http.HttpServletRequest;

import com.ks.commo.Constants;

public class UserUtils {
	public final static boolean isLogin(HttpServletRequest request){
		if (request.getSession().getAttribute(Constants.SESSION_USER_NAME)!=null) {
			return true;
		}
		return false;
		
	}
}
