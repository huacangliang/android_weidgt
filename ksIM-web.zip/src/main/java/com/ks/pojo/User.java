package com.ks.pojo;


public class User{
    private Integer ksUid;

    private String ksName;

    private String ksPhone;

    private String ksLoginPassword;

    private String ksNickeName;

    private Integer ksLevel;

    private Integer ksScore;

    private String ksCreateTime;

    private String ksCreateIp;

    private String ksLoginIp;

    private String ksLoginTime;

    private String ksEmail;

    private String ksHeadIcon;

    private Integer ksVip;

    private String ksStatuMsg;

    private String ksPubRsa;

    private Integer ksStatu;

    public Integer getKsUid() {
        return ksUid;
    }

    public void setKsUid(Integer ksUid) {
        this.ksUid = ksUid;
    }

    public String getKsName() {
        return ksName;
    }

    public void setKsName(String ksName) {
        this.ksName = ksName == null ? null : ksName.trim();
    }

    public String getKsPhone() {
        return ksPhone;
    }

    public void setKsPhone(String ksPhone) {
        this.ksPhone = ksPhone == null ? null : ksPhone.trim();
    }

    public String getKsLoginPassword() {
        return ksLoginPassword;
    }

    public void setKsLoginPassword(String ksLoginPassword) {
        this.ksLoginPassword = ksLoginPassword == null ? null : ksLoginPassword.trim();
    }

    public String getKsNickeName() {
        return ksNickeName;
    }

    public void setKsNickeName(String ksNickeName) {
        this.ksNickeName = ksNickeName == null ? null : ksNickeName.trim();
    }

    public Integer getKsLevel() {
        return ksLevel;
    }

    public void setKsLevel(Integer ksLevel) {
        this.ksLevel = ksLevel;
    }

    public Integer getKsScore() {
        return ksScore;
    }

    public void setKsScore(Integer ksScore) {
        this.ksScore = ksScore;
    }

    public String getKsCreateTime() {
        return ksCreateTime;
    }

    public void setKsCreateTime(String ksCreateTime) {
        this.ksCreateTime = ksCreateTime == null ? null : ksCreateTime.trim();
    }

    public String getKsCreateIp() {
        return ksCreateIp;
    }

    public void setKsCreateIp(String ksCreateIp) {
        this.ksCreateIp = ksCreateIp == null ? null : ksCreateIp.trim();
    }

    public String getKsLoginIp() {
        return ksLoginIp;
    }

    public void setKsLoginIp(String ksLoginIp) {
        this.ksLoginIp = ksLoginIp == null ? null : ksLoginIp.trim();
    }

    public String getKsLoginTime() {
        return ksLoginTime;
    }

    public void setKsLoginTime(String ksLoginTime) {
        this.ksLoginTime = ksLoginTime == null ? null : ksLoginTime.trim();
    }

    public String getKsEmail() {
        return ksEmail;
    }

    public void setKsEmail(String ksEmail) {
        this.ksEmail = ksEmail == null ? null : ksEmail.trim();
    }

    public String getKsHeadIcon() {
        return ksHeadIcon;
    }

    public void setKsHeadIcon(String ksHeadIcon) {
        this.ksHeadIcon = ksHeadIcon == null ? null : ksHeadIcon.trim();
    }

    public Integer getKsVip() {
        return ksVip;
    }

    public void setKsVip(Integer ksVip) {
        this.ksVip = ksVip;
    }

    public String getKsStatuMsg() {
        return ksStatuMsg;
    }

    public void setKsStatuMsg(String ksStatuMsg) {
        this.ksStatuMsg = ksStatuMsg == null ? null : ksStatuMsg.trim();
    }

    public String getKsPubRsa() {
        return ksPubRsa;
    }

    public void setKsPubRsa(String ksPubRsa) {
        this.ksPubRsa = ksPubRsa == null ? null : ksPubRsa.trim();
    }

    public Integer getKsStatu() {
        return ksStatu;
    }

    public void setKsStatu(Integer ksStatu) {
        this.ksStatu = ksStatu;
    }
}