package com.ks.pojo;


public class LoginInfo{
    private Integer ksLgId;

    private String ksLgPhone;

    public Integer getKsLgId() {
        return ksLgId;
    }

    public void setKsLgId(Integer ksLgId) {
        this.ksLgId = ksLgId;
    }

    public String getKsLgPhone() {
        return ksLgPhone;
    }

    public void setKsLgPhone(String ksLgPhone) {
        this.ksLgPhone = ksLgPhone == null ? null : ksLgPhone.trim();
    }
}