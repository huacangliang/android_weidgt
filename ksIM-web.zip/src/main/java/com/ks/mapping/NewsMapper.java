package com.ks.mapping;

import java.util.List;

import com.ks.pojo.News;

public interface NewsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(News record);

    int insertSelective(News record);

    News selectByPrimaryKey(Integer id);
    
    List<News> selectByParam(String title);

    int updateByPrimaryKeySelective(News record);

    int updateByPrimaryKey(News record);
}