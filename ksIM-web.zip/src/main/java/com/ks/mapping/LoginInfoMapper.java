package com.ks.mapping;

import java.util.List;

import com.ks.pojo.LoginInfo;

public interface LoginInfoMapper {
    int deleteByPrimaryKey(Integer ksLgId);

    int insert(LoginInfo record);

    int insertSelective(LoginInfo record);

    LoginInfo selectByPrimaryKey(Integer ksLgId);
    
    LoginInfo selectByPhoneNum(String ksLgPhone);
    
    List<LoginInfo> selectByPage();

    int updateByPrimaryKeySelective(LoginInfo record);

    int updateByPrimaryKey(LoginInfo record);

	int deleteByPhoneNum(String phone);
}