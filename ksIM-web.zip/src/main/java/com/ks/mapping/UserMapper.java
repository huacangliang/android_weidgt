package com.ks.mapping;

import java.util.List;

import com.ks.pojo.User;

public interface UserMapper {
    int deleteByPrimaryKey(Integer ksUid);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer ksUid);
    
    List<User> selectByParam(User user);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
}