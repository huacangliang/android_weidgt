package com.ks.commo;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.ks.pojo.LoginInfo;
import com.ks.pojo.Message;
import com.ks.service.IMessageService;

public class IMService {
	public final static ExecutorService pool = Executors
			.newFixedThreadPool(1000);
	private IMTask task;

	private IMessageService messageService;

	public final void login(IMessageService messageService, String phone) {
		this.messageService = messageService;
		LoginInfo li = new LoginInfo();
		li.setKsLgPhone(phone);
		messageService.loginIM(li);
		startNotifyMsg(phone);
	}

	public final void logOut(IMessageService messageService, String phone) {
		if (task != null) {
			task.isRun = false;
		}
		messageService.logout(phone);
	}

	private void startNotifyMsg(String phone) {
		if (task != null) {
			task.isRun = false;
		}
		task = new IMTask();
		task.messageService = messageService;
		task.isRun = true;
		task.phone = phone;
		pool.execute(task);
	}

	public static class IMTask implements Runnable {
		boolean isRun = false;
		IMessageService messageService;
		private int pageNum = 0;
		private int pageSize = 10;
		String phone = "";

		@Override
		public void run() {
			Message msg = new Message();
			msg.setToPhoneNo(phone);
			while (isRun) {
				List<Message> msgs = messageService.findByPage(msg, pageNum,
						pageSize);
				if (msgs.size() <= 0) {
					return;
				}
				// 在这里调用消息服务器发送消息
				//先删掉取出的消息，如果消息服务器发送失败了会重新保存到数据库的
				for (int i = 0; i < msgs.size(); i++) {
					msg = msgs.get(i);
					messageService.delMsg(msg.getId());
					sendMsg(msg);
					if (!isRun)
						return;
				}
				pageNum++;
			}
		}

		public boolean sendMsg(Message msg) {
			return false;
		}
	}
}
