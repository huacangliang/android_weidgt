package com.ks.commo;

public class Constants {

	public static final String JSONMIMETYPE = "application/json;charset=UTF-8";

	public static final int REGISTER_ERRORCODE = 1;

	public static final int LOGIN_ERRORCODE = 2;

	public static final int UPDATEUSER_ERRORCDE = 3;

	public static final int QUERYUSER_ERRORCODE = 4;

	public static final int DELUSER_ERRORCODE = 5;

	public static final int ADDNEWS_ERRORCDE = 6;

	public static final int UPDATENEWS_ERRORCODE = 7;

	public static final int DELNEWS_ERRORCODE = 8;

	public static final int QUERYNEWS_ERRORCODE = 9;

	public static final int ADDMSG_ERRORCODE = 10;

	public static final int UPDATEMSG_ERRORCODE = 11;

	public static final int DELMSG_ERRORCODE = 12;

	public static final int GETMSG_ERRORCODE = 13;

	public static final int FINDUSER_ERRORCODE = 14;
	
	public static final int LOGOUT_ERRORCODE = 15;

	public static final String SESSION_USER_NAME = "session_user";
}
